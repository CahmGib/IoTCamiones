const { readValuesBD } = require('./service/serviceEjecution.js');

exports.handler = async (event, context) => {
    return await readValuesBD(event['date'], context, event['headers'], event['X-PAGE'], event['X-LIMIT']);
};