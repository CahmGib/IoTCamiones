const { codeResult, internalErrorMsg, codeResultInternalError } = require('./../constants/responses/constantsResponse.js');
const region = process.env.region;
const lambdaAudit = process.env.lambdaAudit;

const AWS = require('aws-sdk');
const lambda = new AWS.Lambda({ region: region });

module.exports.invokeFunctionLambda = (JSONRequest, responseObj, context, headers) => {
    let dataSend = {
        "JSONRequest": JSONRequest,
        "nameFunctionLambda": context['functionName'],
        "responseObj": responseObj,
        "ipRequest": headers['X-Forwarded-For'],
        "Rq-uuid": headers['Rq-uuid']
    };
    let params = {
        FunctionName: lambdaAudit,
        Payload: JSON.stringify(dataSend)
    };
    return new Promise((resolve, reject) => {
        lambda.invoke(params, (error, data) => {
            if (error) {
                let responseObj = {
                    resultado: codeResult,
                    mensaje: internalErrorMsg,
                    codigo: codeResultInternalError
                };
                context.fail(JSON.stringify(responseObj));
            } else {
                resolve(true);
            }
        });
    });
}   