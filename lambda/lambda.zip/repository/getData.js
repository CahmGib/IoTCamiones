const { codeResultErrorBadRequest, errorMsg, msgPageNotFound, msgNotFound, internalErrorMsg, codeResultErrorNotFound, codeResultInternalError } = require('./../constants/responses/constantsResponse.js');
const region = process.env.region;
const nameTable = process.env.nameTable;
const AWS = require("aws-sdk");
const connectTb = new AWS.DynamoDB.DocumentClient({ region: region });

module.exports.getDataAfil = (date, objResponse, xPage, xLimit) => {
    const page = xPage;
    const limit = xLimit;
    let params = {
        TableName: nameTable,
        IndexName: "dateRegister-index",
        KeyConditionExpression: "dateRegister = :dateRegister",
        ExpressionAttributeValues: {
            ":dateRegister": date
        }
    };
    return new Promise((resolve, reject) => {
        if (isNumeric(page) && isNumeric(limit)) {
            getConsultAfil(params, objResponse, Number(page), Number(limit)).then((result) => {
                resolve(result);
            }, (error) => {
                reject(error);
            });
        } else {
            reject(returnErrorMsg(objResponse, errorMsg, codeResultErrorBadRequest));
        }
    });
}

//Method that consult ddata from afiliation
const getConsultAfil = (params, objResponse, page, limit) => {
    return new Promise((resolve, reject) => {
        connectTb.query(params, (error, data) => {
            if (error) {
                reject(returnErrorMsg(objResponse, internalErrorMsg, codeResultInternalError));
            } else {
                if (data['Items'].length > 0) {
                    let objResponseGet = divideInPages(limit, data).filter((item) => {
                        return item.pagina === page
                    });
                    if (objResponseGet.length > 0) {
                        resolve(objResponseGet[0]);
                    } else {
                        reject(returnErrorMsg(objResponse, msgPageNotFound, codeResultErrorNotFound));                        
                    }                    
                } else {
                    reject(returnErrorMsg(objResponse, msgNotFound, codeResultErrorNotFound));
                }
            }
        });
    });
}

//Method that divide result of consult in pages
const divideInPages = (limit, data) => {
    let pagesItems = [];
    let i = 0;
    let i2 = 0;
    while (i < data['Items'].length) {
        pagesItems.push({
            Solicitudes: data['Items'].slice(i, i + limit).map((item) => {
                return assignProperty(item);
            }),
            pagina: i2 + 1
        });
        i += limit;
        i2++;
    }
    pagesItems.forEach((item) => {
        item['paginasTotales'] = i2;
    });
    return pagesItems;
}

//Method that return error
const returnErrorMsg = (objResponse, msgError, codeResultError) => {
    objResponse['mensaje'] = msgError;
    objResponse['codigo'] = codeResultError;
    return objResponse;
}

//Method that validates if the string is a valid number
const isNumeric = (str) => {
    if (typeof str != "string") {
        return false;
    } else {
        return !isNaN(str) && !isNaN(parseFloat(str));
    }
}

//Method that assignate property solicitud to object and delete propertie dateRegister
const assignProperty = (obj) => {
    delete obj['dateRegister'];
    let newObj = {
        "Solicitud": obj
    };
    return newObj;
}