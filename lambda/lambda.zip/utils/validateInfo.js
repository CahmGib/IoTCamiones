const { errorMsg, okMsg } = require('./../constants/responses/constantsResponse.js');
const { nBeginCodDocumJ, nFinCodDocumJ, nBeginCodDocumN, nFinCodDocumN, typePersonJ, typePersonN } = require('./../constants/dataValidation/constantsDataVal.js');

//Method that validates the JSON
module.exports.validateJSON = (objJSON) => {
    try {
        for (let key of Object.keys(objJSON)) {
            validateKeyJSON(key, objJSON);
        }
        return okMsg;
    } catch (e) {
        return e;
    }
}

//Method that helps to validate the JSON
const validateKeyJSON = (key, objJSON) => {
    switch (key) {
        case 'numeroIdentificacionEmpleador':
            validateCodDocum(objJSON, "tipoIdentificacionEmpleador", key);
            break;
        case 'primerNombrePersonaNatural':
            validateDataTypeNatu(objJSON, key);
            break;
        case 'segundoNombrePersonaNatural':
            validateDataTypeNatu(objJSON, key);
            break;
        case 'primerApellidoPersonaNatural':
            validateDataTypeNatu(objJSON, key);
            break;
        case 'segundoApellidoPersonaNatural':
            validateDataTypeNatu(objJSON, key);
            break;
        case 'fechadeNacimientoPersonaNatural':
            if (isValidDate(objJSON[key])) {
                validateDataTypeNatu(objJSON, key);
            } else {
                throw errorMsg;
            }
            break;
        case 'nacionalidadPersonaNatural':
            validateDataTypeNatu(objJSON, key);
            break;
        case 'numeroDocumentoIdentificacionRepresentanteLegal':
            validateCodDocum(objJSON, "tipoDocumentoIdentificacionRepresentanteLegal", key);
            break;
        case 'fechaHoraTransaccionEnSat':
            validateDateTime(objJSON[key]);
            break;
    }
}

//Method to validate codDocument
const validateCodDocum = (objJSON, typeDocum, codDocum) => {
    let typeCodDocum = objJSON[typeDocum];
    let codDocumStr = objJSON[codDocum];
    let typePerson = objJSON['tipoPersona'];
    const validations = validateDataCodDoc(typeCodDocum, typePerson);
    if (!validations) {
        throw errorMsg;
    } else {
        validateNumericCodDoc(validations, codDocumStr);
        validateLengthCodDocum(validations, codDocumStr);
        validateLimitValuesCodDocum(validations, codDocumStr);
    }
}

//Method that validate numeric and validation cod Docum
const validateNumericCodDoc = (validation, codDocum) => {
    if (validation.isNumeric && !isNumeric(codDocum)) {
        throw errorMsg;
    }
}

//Method that validate length of codDocum
const validateLengthCodDocum = (validation, codDocum) => {
    if (Array.isArray(validation.length)) {
        if (codDocum.length < validation.length[0] || codDocum.length > validation.length[1]) {
            throw errorMsg;
        }
    } else if (codDocum.length !== validation.length) {
        throw errorMsg;
    }
}

//Method that validate min or max values of codDocum
const validateLimitValuesCodDocum = (validation, codDocum) => {
    if (validation.min || validation.max) {
        let codDocumNumber = parseInt(codDocum);
        if (codDocumNumber < validation.min || codDocumNumber > validation.max) {
            throw errorMsg;
        }
    }
}

//Method that help validate data od cod Docum
const validateDataCodDoc = (typeCodDocum, typePerson) => {
    let validation = {
        'NI': {
            isNumeric: true,
            length: 9
        },
        'CC': {isNumeric: true, length: [3, 10]},
        'CE': {isNumeric: true, length: 7},
        'PA': {length: [3, 16]},
        'CD': {length: [3, 11]},
        'SC': {isNumeric: true, length: 9},
        'PE': {isNumeric: true, length: 15},
        'PT': {isNumeric: true, length: [0, 8]}
    };
    let minLengthDocumNI = 0;
    let maxLengthDocumNI = 0;
    if (typePerson === typePersonJ) {
        minLengthDocumNI = nBeginCodDocumJ;
        maxLengthDocumNI = nFinCodDocumJ;
    } else if (typePerson === typePersonN) {
        minLengthDocumNI = nBeginCodDocumN;
        maxLengthDocumNI = nFinCodDocumN;
    }
    validation['NI']['min'] = minLengthDocumNI;
    validation['NI']['max'] = maxLengthDocumNI;
    return validation[typeCodDocum];
}

//Method that validates if the string is a valid number
const isNumeric = (str) => {
    if (typeof str != "string") {
        return false;
    } else {
        return !isNaN(str) && !isNaN(parseFloat(str));
    }
}

//Method that validates the data of natural persons type (N)
const validateDataTypeNatu = (objJSON, keyJSON) => {
    let typePerson = objJSON["tipoPersona"];
    if (typePerson === typePersonJ) {
        objJSON[keyJSON] = "";
    }
}

//Validates that the input string is a valid date formatted as "AAAA-MM-DD"
const isValidDate = (dateString) => {
    // First check for the pattern
    if(!/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateString)) {
        return false;
    }
    // Parse the date parts to integers
    let parts = dateString.split("-");
    let day = parseInt(parts[2], 10);
    let month = parseInt(parts[1], 10);
    let year = parseInt(parts[0], 10);
    // Check the ranges of month and year
    if(year < 1000 || year > 3000 || month == 0 || month > 12) {
        return false;
    }
    let monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    // Adjust for leap years
    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) {
        monthLength[1] = 29;
    }
    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
};

//Export method validate date
module.exports.expIsValidDate = (dateStr) => {
    return isValidDate(dateStr);
}

//Method that validates the value of the fechaHoraTransaccionEnSat
const validateDateTime = (dateTimeStr) => {
    let dateStr = dateTimeStr.split(" ")[0];
    let timeStr = dateTimeStr.split(" ")[1];
    if (!isValidDate(dateStr) || !validateHhMm(timeStr)) {
        throw errorMsg;
    }
}

//Method that validates the time
const validateHhMm = (timeStr) => {
    let isValid = /^([0-1]?\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/.test(timeStr);
    return isValid;
}