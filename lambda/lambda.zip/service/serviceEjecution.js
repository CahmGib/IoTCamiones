const { codeResult, errorMsg, codeResultErrorBadRequest } = require('./../constants/responses/constantsResponse.js');
const { expIsValidDate } = require('./../utils/validateInfo.js');
const { getDataAfil } = require('./../repository/getData.js');
const { invokeFunctionLambda } = require('./../repository/audit.js');

//Creation of promise querying table data
module.exports.readValuesBD = async (date, context, headers, xPage, xLimit) => {
    let objResponse = {
        resultado: codeResult,
        mensaje: "",
        codigo: ""
    };
    let flagError = false;
    if (expIsValidDate(date)) {
        await getDataAfil(date, objResponse, xPage, xLimit).then((result) => {
            objResponse = result;
        }, (error) => {
            flagError = true;
            objResponse = error;
        });
    } else {
        objResponse['mensaje'] = errorMsg;
        objResponse['codigo'] = codeResultErrorBadRequest;
        flagError = true;
    }
    await invokeFunctionLambda(date, objResponse, context, headers);
    if (flagError) {
        context.fail(JSON.stringify(objResponse));
    } else {
        return objResponse;
    }
}