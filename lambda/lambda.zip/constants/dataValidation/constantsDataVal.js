module.exports.nBeginCodDocumJ = 800000000;
module.exports.nFinCodDocumJ = 999999999;
module.exports.nBeginCodDocumN = 600000000;
module.exports.nFinCodDocumN = 799999999;
module.exports.typePersonJ = "J";
module.exports.typePersonN = "N";